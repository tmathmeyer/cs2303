void print_array(int* test);
void iterate(int* B, int* D);
void put(int* test, int x, int y, int value);
void run_iterations(int* a, int* b, int* c, int itr, int print, int pause);
int* read_file(int* array, char *filename, int w, int h);

int get_surrounding(int* test, int x, int y);
int get(int* test, int x, int y);
int are_equal(int* a, int* b);